# Perceptron과 ANN

# 1. 기본 개념

- 차이점
    - 한 개 이상의 Hidden Layer
    - 다중 층을 활용한 비선형 패턴 인지(Sigmoid 활용)
- 유사점
    - Feed-Forward 한쪽 방향으로 학습

    ![Perceptron%E1%84%80%E1%85%AA%20ANN%20fe797bbf20074cc1909fee95e5fa2e55/Untitled.png](Perceptron%E1%84%80%E1%85%AA%20ANN%20fe797bbf20074cc1909fee95e5fa2e55/Untitled.png)

# 2. 사전 지식

🐗 sigmoid

# 3. 자세한 학습

[특잇값 분해의 사본](Perceptron%E1%84%80%E1%85%AA%20ANN%20fe797bbf20074cc1909fee95e5fa2e55/%E1%84%90%E1%85%B3%E1%86%A8%E1%84%8B%E1%85%B5%E1%86%BA%E1%84%80%E1%85%A1%E1%86%B9%20%E1%84%87%E1%85%AE%E1%86%AB%E1%84%92%E1%85%A2%E1%84%8B%E1%85%B4%20%E1%84%89%E1%85%A1%E1%84%87%E1%85%A9%E1%86%AB%205cee15bdbfa9488196afbeeca1f379e0.md)

[Sigmoid](Perceptron%E1%84%80%E1%85%AA%20ANN%20fe797bbf20074cc1909fee95e5fa2e55/Sigmoid%20942ee6ab3b504b8ba254344b95f5a175.md)

---

# 출처

---

[Artificial Neural Networks](https://nathanh.tistory.com/53)