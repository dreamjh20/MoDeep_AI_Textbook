# 교과서 템플릿의 사본

# 1. 기본 개념

- 데이터 과학이란 정형, 비정형 형태를 포함한 다양한 데이터로부터 지식을 추출하는데 과학적 방법론, 프로세스, 알고리즘 시스템을 동원하는 융합 분야이다.
-위키백과

# 2. 사전 지식

아래와 같은 사전지식이 있어야 원할하게 해당 개념을 이해할 수 있음을 알려드립니다.

# 3. 자세한 학습

[기본연산의 사본](%E1%84%80%E1%85%AD%E1%84%80%E1%85%AA%E1%84%89%E1%85%A5%20%E1%84%90%E1%85%A6%E1%86%B7%E1%84%91%E1%85%B3%E1%86%AF%E1%84%85%E1%85%B5%E1%86%BA%E1%84%8B%E1%85%B4%20%E1%84%89%E1%85%A1%E1%84%87%E1%85%A9%E1%86%AB%206f7a88e3bbee44be8a5fba6fffa18768/%E1%84%80%E1%85%B5%E1%84%87%E1%85%A9%E1%86%AB%E1%84%8B%E1%85%A7%E1%86%AB%E1%84%89%E1%85%A1%E1%86%AB%E1%84%8B%E1%85%B4%20%E1%84%89%E1%85%A1%E1%84%87%E1%85%A9%E1%86%AB%2042db4968c0b440e8a1079f9e72c56ea3.md)

[특잇값 분해의 사본](%E1%84%80%E1%85%AD%E1%84%80%E1%85%AA%E1%84%89%E1%85%A5%20%E1%84%90%E1%85%A6%E1%86%B7%E1%84%91%E1%85%B3%E1%86%AF%E1%84%85%E1%85%B5%E1%86%BA%E1%84%8B%E1%85%B4%20%E1%84%89%E1%85%A1%E1%84%87%E1%85%A9%E1%86%AB%206f7a88e3bbee44be8a5fba6fffa18768/%E1%84%90%E1%85%B3%E1%86%A8%E1%84%8B%E1%85%B5%E1%86%BA%E1%84%80%E1%85%A1%E1%86%B9%20%E1%84%87%E1%85%AE%E1%86%AB%E1%84%92%E1%85%A2%E1%84%8B%E1%85%B4%20%E1%84%89%E1%85%A1%E1%84%87%E1%85%A9%E1%86%AB%20ac2b3d6af7f84740806350ff0af8ae85.md)

---

# 출처

---

[Beyond Frank Lloyd Wright: A Broader View of Art in Chicago](https://www.nytimes.com/2018/03/08/arts/chicago-museums-art.html?rref=collection%2Fsectioncollection%2Ftravel)

[Havana's Symphony of Sound](https://www.nytimes.com/2018/03/12/travel/havana-cuba.html?rref=collection%2Fsectioncollection%2Ftravel)