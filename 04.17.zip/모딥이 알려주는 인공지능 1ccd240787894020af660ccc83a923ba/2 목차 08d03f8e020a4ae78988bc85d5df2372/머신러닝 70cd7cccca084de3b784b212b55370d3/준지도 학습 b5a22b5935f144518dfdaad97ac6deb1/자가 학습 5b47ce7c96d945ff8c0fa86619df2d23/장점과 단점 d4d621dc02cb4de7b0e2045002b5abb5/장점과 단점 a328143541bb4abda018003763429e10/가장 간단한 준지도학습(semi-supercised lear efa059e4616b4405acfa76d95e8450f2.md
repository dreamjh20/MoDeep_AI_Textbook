# 가장 간단한 준지도학습(semi-supercised learning)이다.

단점: 초반에 잘못 저지른 실수(early mistakes)가 잘못된 길로 인도할 수 있다.